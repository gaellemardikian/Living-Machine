var searchData=
[
  ['suspect_5fcaract_30',['suspect_caract',['../robot__police__cam__mac_8cpp.html#afaad4b1e456db54193e7133e229ec550',1,'robot_police_cam_mac.cpp']]]
];
