var searchData=
[
  ['face_34',['face',['../structSuspect.html#aef245452528e93b5b64d7e73e560ad24',1,'Suspect']]],
  ['fps_5fapres_5fperte_35',['fps_apres_perte',['../structSuspect.html#a6a3ebc2d03cf2bf8dfd7e772b56914ce',1,'Suspect']]]
];
