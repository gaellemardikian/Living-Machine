var searchData=
[
  ['camera_5fred_5fdetect_2ecpp_21',['camera_red_detect.cpp',['../camera__red__detect_8cpp.html',1,'']]]
];
