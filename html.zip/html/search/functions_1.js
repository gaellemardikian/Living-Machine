var searchData=
[
  ['fichier_5fcouleur_24',['fichier_couleur',['../camera__red__detect_8cpp.html#ad46c516c6374ae5a01906a1fbf2127f4',1,'camera_red_detect.cpp']]]
];
